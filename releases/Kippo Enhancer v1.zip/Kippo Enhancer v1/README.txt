Kippo Enhancer v1 by kill0rz - visit http://kill0rz.com/

+++ Beschreibung +++

Dieses Script erweitert deine Nutzerdatenbank des Honeypots Kippo um alle m�glichen Benutzer/Passwort-Kombinationen, basierend auf den bisherigen Eintr�gen und deinen Kippo-Logs.

+++ Installation +++

�ffne die index.php und passe in den Zeilen 16 und 17 die Einstellungen an.
In Zeile 16 gibts du den Installationspfad von kippo an (mit / am Ende) und in der 17 kannst du dem Script eine bestimmte Menge RAM zuweisen (je nach Gr��e ist hier 1G schon sinnvoll).

+++ Anwendung +++

Einfach die index.php aufrufen. Es wird eine Statistik zur�ckgegeben.
Au�erdem werden Backups von der Datenbank und den Logs angelegt. Bitte stelle sicher, dass das Script Schreibrechte hat.

+++ Lizenz +++

Dieses Script wurde unter kill0rz Unilicence v1 ver�ffentlicht. Diese liegt bei.


Viel Spa� bei der Anwendung,
kill0rz

Stand 11.01.2015